from django.contrib import admin
from .models import Theatre ,Show
# Register your models here.
admin.site.register(Theatre)
admin.site.register(Show)